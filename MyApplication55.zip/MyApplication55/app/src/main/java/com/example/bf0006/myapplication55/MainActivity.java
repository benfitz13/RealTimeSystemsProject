package com.example.bf0006.myapplication55;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import static com.example.bf0006.myapplication55.R.id.tableLayout;

public class MainActivity extends AppCompatActivity {
    int score = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_main);
        Button btnAddItem = (Button) findViewById(R.id.addItemTableRow);
        btnAddItem.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                TableLayout table = (TableLayout) findViewById(R.id.tableLayout);
                //create a new row to add
                TableRow row = new TableRow(MainActivity.this);
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                //add Layouts to your new row
                TextView txt = new TextView(MainActivity.this);
                txt.setText("T" + score);
                score++;
                //row.addView(txt);
                TextView txt1 = new TextView(MainActivity.this);
                txt.setText("test");
                score++;
                row.addView(txt1 );
                //add your new row to the TableLayout:

                table.addView(row);

            }
        });

/*
public void onClick(View v) {
    // TODO Auto-generated method stub
    LayoutInflater inflator = MainActivity.this.getLayoutInflater();
    TableRow rowView = new TableRow(v.getContext());
    inflator.inflate(R.layout.activity_main, rowView);
    TableLayout mainLayout = (TableLayout) findViewById(R.id.tableLayout);
    mainLayout.addView(rowView);

}
});
*/
       /* final EditText numberField = (EditText) findViewById(R.id.EditTextNumber);
        String number = numberField.getText().toString();

        final EditText dateField = (EditText) findViewById(R.id.EditTextDate);
        String date = dateField.getText().toString();

        final EditText stateField = (EditText) findViewById(R.id.EditTextState);
        String state = stateField.getText().toString();

        final EditText nameField = (EditText) findViewById(R.id.EditTextName);
        String name = nameField.getText().toString();

        final EditText addressField = (EditText) findViewById(R.id.EditTextAddress);
        String address = addressField.getText().toString();
        */
/*
        final EditText feedbackField = (EditText) findViewById(R.id.EditTextFeedbackBody);
        String feedback = feedbackField.getText().toString();

        final EditText nameField = (EditText) findViewById(R.id.EditTextName);
        String name = nameField.getText().toString();

        final EditText emailField = (EditText) findViewById(R.id.EditTextEmail);
        String email = emailField.getText().toString();

        final EditText feedbackField = (EditText) findViewById(R.id.EditTextFeedbackBody);
        String feedback = feedbackField.getText().toString();

        final EditText nameField = (EditText) findViewById(R.id.EditTextName);
        String name = nameField.getText().toString();

        final EditText emailField = (EditText) findViewById(R.id.EditTextEmail);
        String email = emailField.getText().toString();

        final EditText feedbackField = (EditText) findViewById(R.id.EditTextFeedbackBody);
        String feedback = feedbackField.getText().toString();

        final EditText nameField = (EditText) findViewById(R.id.EditTextName);
        String name = nameField.getText().toString();

        final EditText emailField = (EditText) findViewById(R.id.EditTextEmail);
        String email = emailField.getText().toString();

        final EditText feedbackField = (EditText) findViewById(R.id.EditTextFeedbackBody);
        String feedback = feedbackField.getText().toString();

        final EditText nameField = (EditText) findViewById(R.id.EditTextName);
        String name = nameField.getText().toString();

        final EditText emailField = (EditText) findViewById(R.id.EditTextEmail);
        String email = emailField.getText().toString();

        final EditText feedbackField = (EditText) findViewById(R.id.EditTextFeedbackBody);
        String feedback = feedbackField.getText().toString();

*/

        }
    }

